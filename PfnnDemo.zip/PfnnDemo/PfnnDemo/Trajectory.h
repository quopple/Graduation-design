#ifndef _TRAJECTORY_
#define _TRAJECTORY_

#include <vector>
#include <glm/glm.hpp>

class Trajectory
{
public:
	Trajectory(const int length, const int subsampleRate, float w, const int nucp);
	~Trajectory();

	const int LENGTH;
	const int subsampleRate;

	float width;

	std::vector<glm::vec3> positions;
	std::vector<glm::vec3> directions;
	std::vector<glm::mat3> rotations;
	std::vector<float> heights;

	std::vector<std::vector<float>> ucps;

	glm::vec3 target_dir, target_vel;
};


#endif