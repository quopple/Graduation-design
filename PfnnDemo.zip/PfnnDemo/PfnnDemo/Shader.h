#ifndef _SHADER_
#define _SHADER_

#include <gl/glew.h>

class Shader
{
public:
	Shader();
	~Shader();

	GLuint program;
	GLuint vs, fs;

	void load_shader(const char* filename, GLenum type, GLuint *shader);
	void load(const char* vertex, const char* fragment);
};

#endif