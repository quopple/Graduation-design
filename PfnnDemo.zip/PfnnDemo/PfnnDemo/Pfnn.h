#ifndef _PFNN_
#define _PFNN_

#include <Eigen/Dense>
using namespace Eigen;

#include <vector>
#include <string>
using namespace std;

class Pfnn
{
public:
	Pfnn(int pfnnmode, const int xdim, const int ydim, const int hdim, const int layer);
	~Pfnn();

	static void load_weights(ArrayXXf &A, int rows, int cols, const char* fmt, ...);
	static void load_weights(ArrayXf &V, int items, const char* fmt, ...);
	static void ELU(ArrayXf &x);

	static void linear(ArrayXf  &o, const ArrayXf  &y0, const ArrayXf  &y1, float mu);
	static void linear(ArrayXXf &o, const ArrayXXf &y0, const ArrayXXf &y1, float mu);

	static void cubic(ArrayXf  &o, const ArrayXf &y0, const ArrayXf &y1, const ArrayXf &y2, const ArrayXf &y3, float mu);
	static void cubic(ArrayXXf &o, const ArrayXXf &y0, const ArrayXXf &y1, const ArrayXXf &y2, const ArrayXXf &y3, float mu);

	void load(string networkDir);
	void predict(float P);

	const int XDIM, YDIM, HDIM, LAYER;
	enum { MODE_CONSTANT, MODE_LINEAR, MODE_CUBIC };

	int mode;

	ArrayXf Xmean, Xstd;
	ArrayXf Ymean, Ystd;

	vector<vector<ArrayXXf>> W;
	vector<vector<ArrayXf>> b;

	ArrayXf  Xp, Yp;
};

#endif