#ifndef _OPTIONS_
#define _OPTIONS_

class Options {
public:
	bool invert_y;

	bool enable_ik;

	bool display_debug;
	bool display_debug_heights;
	bool display_debug_joints;
	bool display_debug_pfnn;

	float display_scale;

	float extra_direction_smooth;
	float extra_velocity_smooth;
	float extra_strafe_smooth;
	float extra_ucp_smooth;
	float extra_joint_smooth;

	Options()
		: invert_y(false)
		, enable_ik(false)
		, display_debug(true)
		, display_debug_heights(true)
		, display_debug_joints(true)
		, display_debug_pfnn(false)
		, display_scale(2.0)

		, extra_direction_smooth(0.9)
		, extra_velocity_smooth(0.9)
		, extra_strafe_smooth(0.9)
		, extra_ucp_smooth(0.1)
		, extra_joint_smooth(0.5)
	{}
};

#endif