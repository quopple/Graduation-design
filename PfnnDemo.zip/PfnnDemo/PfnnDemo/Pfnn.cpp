#include "Pfnn.h"
#include <stdarg.h>
#include <fstream>

#define _USE_MATH_DEFINES
#include <math.h>


Pfnn::Pfnn(int pfnnmode, const int xdim, const int ydim, const int hdim, const int layer)
: mode(pfnnmode)
, XDIM(xdim)
, YDIM(ydim)
, HDIM(hdim)
, LAYER(layer)
, W(layer)
, b(layer)
{
	Xp = ArrayXf(XDIM);
	Yp = ArrayXf(YDIM);
}

Pfnn::~Pfnn()
{
}

void Pfnn::load_weights(ArrayXXf &A, int rows, int cols, const char* fmt, ...)
{
	va_list valist;
	va_start(valist, fmt);
	char filename[512];
	vsprintf_s(filename, fmt, valist);
	va_end(valist);

	FILE *f;
	fopen_s(&f, filename, "rb");
	if (f == NULL) { fprintf_s(stderr, "Couldn't load file %s\n", filename); exit(1); }

	A = ArrayXXf(rows, cols);
	for (int x = 0; x < rows; x++)
	for (int y = 0; y < cols; y++) {
		float item = 0.0;
		fread(&item, sizeof(float), 1, f);
		A(x, y) = item;
	}
	fclose(f);
}

void Pfnn::load_weights(ArrayXf &V, int items, const char* fmt, ...)
{
	va_list valist;
	va_start(valist, fmt);
	char filename[512];
	vsprintf_s(filename, fmt, valist);
	va_end(valist);

	FILE *f;
	fopen_s(&f, filename, "rb");
	if (f == NULL) { fprintf(stderr, "Couldn't load file %s\n", filename); exit(1); }

	V = ArrayXf(items);
	for (int i = 0; i < items; i++) {
		float item = 0.0;
		fread(&item, sizeof(float), 1, f);
		V(i) = item;
	}
	fclose(f);
}

void Pfnn::load(string networkDir)
{
	load_weights(Xmean, XDIM, (networkDir + "/Xmean.bin").data());
	load_weights(Xstd, XDIM, (networkDir + "/Xstd.bin").data());
	load_weights(Ymean, YDIM, (networkDir + "/Ymean.bin").data());
	load_weights(Ystd, YDIM, (networkDir + "/Ystd.bin").data());

	int piece = 0;
	float factor = 0;


	switch (mode)
	{
	case MODE_CONSTANT:

		piece = 50;
		factor = 1;

		break;

	case MODE_LINEAR:

		piece = 10;
		factor = 5;

		break;

	case MODE_CUBIC:

		piece = 4;
		factor = 12.5;

		break;
	}

	for (int i = 0; i < LAYER; ++i)
	{
		W[i].resize(piece);
		b[i].resize(piece);
	}

	for (int i = 0; i < piece; ++i)
	{
		load_weights(W[0][i], HDIM, XDIM, (networkDir + "/W00_%03i.bin").data(), (int)(i*factor));
		for (int j = 1; j < LAYER - 1; ++j)
		{
			load_weights(W[j][i], HDIM, HDIM, (networkDir + "/W%02i_%03i.bin").data(), j, (int)(i*factor));
		}
		load_weights(W[LAYER - 1][i], YDIM, HDIM, (networkDir + "/W%02i_%03i.bin").data(), LAYER - 1, (int)(i*factor));

		for (int j = 0; j < LAYER - 1; ++j)
		{
			load_weights(b[j][i], HDIM, (networkDir + "/b%02i_%03i.bin").data(), j, (int)(i*factor));
		}
		load_weights(b[LAYER - 1][i], YDIM, (networkDir + "/b%02i_%03i.bin").data(), LAYER - 1, (int)(i*factor));
	}
}

void Pfnn::ELU(ArrayXf &x)
{
	x = x.max(0) + x.min(0).exp() - 1;
}

void Pfnn::linear(ArrayXf  &o, const ArrayXf  &y0, const ArrayXf  &y1, float mu)
{
	o = (1.0f - mu) * y0 + (mu)* y1;
}

void Pfnn::linear(ArrayXXf &o, const ArrayXXf &y0, const ArrayXXf &y1, float mu)
{
	o = (1.0f - mu) * y0 + (mu)* y1;
}

void Pfnn::cubic(ArrayXf  &o, const ArrayXf &y0, const ArrayXf &y1, const ArrayXf &y2, const ArrayXf &y3, float mu)
{
	o = (
		(-0.5*y0 + 1.5*y1 - 1.5*y2 + 0.5*y3)*mu*mu*mu +
		(y0 - 2.5*y1 + 2.0*y2 - 0.5*y3)*mu*mu +
		(-0.5*y0 + 0.5*y2)*mu +
		(y1));
}

void Pfnn::cubic(ArrayXXf &o, const ArrayXXf &y0, const ArrayXXf &y1, const ArrayXXf &y2, const ArrayXXf &y3, float mu)
{
	o = (
		(-0.5*y0 + 1.5*y1 - 1.5*y2 + 0.5*y3)*mu*mu*mu +
		(y0 - 2.5*y1 + 2.0*y2 - 0.5*y3)*mu*mu +
		(-0.5*y0 + 0.5*y2)*mu +
		(y1));
}

void Pfnn::predict(float P)
{
	float pamount;
	int pindex_0, pindex_1, pindex_2, pindex_3,i;
	ArrayXXf Wp;
	ArrayXf  bp;
	ArrayXf  H;

	H = Xp = (Xp - Xmean) / Xstd;

	switch (mode) {

	case MODE_CONSTANT:
		pindex_1 = (int)((P / (2 * M_PI)) * 50);
		for (i = 0; i < LAYER-1; ++i)
		{
			H = (W[i][pindex_1].matrix() * H.matrix()).array() + b[i][pindex_1];
			ELU(H);
		}
		Yp = (W[i][pindex_1].matrix() * H.matrix()).array() + b[i][pindex_1];

		break;

	case MODE_LINEAR:
		pamount = fmod((P / (2 * M_PI)) * 10, 1.0);
		pindex_1 = (int)((P / (2 * M_PI)) * 10);
		pindex_2 = ((pindex_1 + 1) % 10);

		for (i = 0; i < LAYER - 1; ++i)
		{
			linear(Wp, W[i][pindex_1], W[i][pindex_2], pamount);
			linear(bp, b[i][pindex_1], b[i][pindex_2], pamount);
			H = (Wp.matrix() * H.matrix()).array() + bp ;
			ELU(H);
		}
		linear(Wp, W[i][pindex_1], W[i][pindex_2], pamount);
		linear(bp, b[i][pindex_1], b[i][pindex_2], pamount);
		Yp = (Wp.matrix() * H.matrix()).array() + bp;

		break;

	case MODE_CUBIC:
		pamount = fmod((P / (2 * M_PI)) * 4, 1.0);
		pindex_1 = (int)((P / (2 * M_PI)) * 4);
		pindex_0 = ((pindex_1 + 3) % 4);
		pindex_2 = ((pindex_1 + 1) % 4);
		pindex_3 = ((pindex_1 + 2) % 4);

		for (i = 0; i < LAYER - 1; ++i)
		{
			cubic(Wp, W[i][pindex_0], W[i][pindex_1], W[i][pindex_2], W[i][pindex_3], pamount);
			cubic(bp, b[i][pindex_0], b[i][pindex_1], b[i][pindex_2], b[i][pindex_3], pamount);
			H = (Wp.matrix() * H.matrix()).array() + bp ;
			ELU(H);
		}
		cubic(Wp, W[i][pindex_0], W[i][pindex_1], W[i][pindex_2], W[i][pindex_3], pamount);
		cubic(bp, b[i][pindex_0], b[i][pindex_1], b[i][pindex_2], b[i][pindex_3], pamount);
		Yp = (Wp.matrix() * H.matrix()).array() + bp;

		break;

	default:
		break;
	}

	Yp = (Yp * Ystd) + Ymean;
}