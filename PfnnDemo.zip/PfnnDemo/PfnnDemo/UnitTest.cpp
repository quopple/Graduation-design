//#define _TEST_

#ifdef _TEST_

#include <string>

#include <glm/glm.hpp>
#include <exception>

#include "Shader.h"


#include "Areas.h"
#include "CameraOrbit.h"
#include "Character.h"
#include "Heightmap.h"
#include "Pfnn.h"
#include "Trajectory.h"
#include "HelperFunc.h"
#include "RenderPipe.h"

#include <gl/glew.h>
#include <gl/glut.h>
#pragma  comment( lib,"glew32.lib" )

#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#pragma  comment( lib,"SDL2.lib" )
#pragma  comment( lib,"SDL2main.lib" )
#pragma  comment( lib,"opengl32.lib" )

bool testShaderClass(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(320, 320);
	glutCreateWindow("GLUT");

	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		fprintf_s(stderr, "Error: %s\n", glewGetErrorString(err));
		exit(1);
	}

	Shader terr_sh;
	terr_sh.load("./shaders/terrain.vs", "./shaders/terrain_low.fs");

	return true;
}

bool testAreaClass()
{
	Areas areas;
	areas.clear();
	areas.add_wall(glm::vec2(1225, -1000), glm::vec2(1225, 1000), 20);
	areas.add_jump(glm::vec3(237.64, 5, 452.98), 75, 100);
	areas.add_crouch(glm::vec3(1225, -1000,30), glm::vec2(1225, 1000));
	areas.clear();

	return true;
}

bool testCameraOrbitClass()
{
	CameraOrbit camera(300,400);
	auto dir = camera.direction();
	auto pos = camera.position();
	auto pro_matrix = camera.proj_matrix();
	auto view_matrix = camera.view_matrix();

	return true;
}

bool testCharacterClass(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(320, 320);
	glutCreateWindow("GLUT");

	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		fprintf_s(stderr, "Error: %s\n", glewGetErrorString(err));
		exit(1);
	}
	int jids[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	try
	{

		Character character(31,jids, 66918, 11200);
		character.load(
			"./shaders/character_vertices.bin",
			"./shaders/character_triangles.bin",
			"./shaders/character_parents.bin",
			"./shaders/character_xforms.bin");
		character.forward_kinematics();
	}
	catch (std::exception &e)
	{
		return false;
	}
	return true;
}

bool testHeightmapClass(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(320, 320);
	glutCreateWindow("GLUT");

	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		fprintf_s(stderr, "Error: %s\n", glewGetErrorString(err));
		exit(1);
	}

	Heightmap h;
	h.load("./shaders/hmap_000_smooth.txt", 1.0);
	auto t = h.sample(glm::vec2(0, 0));

	return true;
}

bool testPfnnClass()
{
	Pfnn pfnn(Pfnn::MODE_CONSTANT, 342, 311, 512,3);
	pfnn.load("./pfnn");
	pfnn.predict(0.0);

	return true;
}

bool testTrajectoryClass()
{
	Trajectory traj(120, 25, 6);

	return true;
}

bool testInitFunc()
{
	auto res = initInfoParse("C:\\Users\\41258\\Desktop\\singleAnim\\data\\ini.txt");

	if (res.size() != 0)
		return true;
	else
		return false;
}

RenderPipe render;
bool mouseLeftDown = false;
bool mouseRightDown = false;
float mouseX, mouseY;
float cameraDistanceX;
float cameraDistanceY;
float cameraAngleX;
float cameraAngleY;
float times = 1;

void draw()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glScalef(times, times, times);//����
	glTranslatef(cameraDistanceX, cameraDistanceY, 0);
	glRotatef(cameraAngleX, 1, 0, 0);
	glRotatef(cameraAngleY, 0, 1, 0);

	render.pre_render();
	render.render();
	render.post_render();
}

void mouseFunc(int button, int state, int x, int y)
{
	mouseX = x;
	mouseY = y;
	times = 1;

	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			mouseLeftDown = true;
		}
		else if (state == GLUT_UP)
			mouseLeftDown = false;
	}

	else if (button == GLUT_RIGHT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			mouseRightDown = true;
		}
		else if (state == GLUT_UP)
			mouseRightDown = false;
	}

	/*
	* �����ֿ���ͼ������
	*/
	else if (state == GLUT_UP && button == GLUT_WHEEL_UP)
	{
		times = 0.008f + 1;
		glutPostRedisplay();
	}

	else if (state == GLUT_UP && button == GLUT_WHEEL_DOWN)
	{
		times = 1 - 0.008f ;
		glutPostRedisplay();
	}
}

void mouseMove(int x , int y)
{
	if (mouseLeftDown)
	{
		cameraAngleY += (x - mouseX) * 0.1f;
		cameraAngleX += (y - mouseY) * 0.1f;
		mouseX = x;
		mouseY = y;
	}
	if (mouseRightDown)
	{
		cameraDistanceX = (x - mouseX) * 0.002f;
		cameraDistanceY = -(y - mouseY) * 0.002f;
		mouseY = y;
		mouseX = x;
	}

	glutPostRedisplay();
}

void testOpenglTimer(int argc, char* argv[])
{
	/* Init glut */

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(720, 640);
	glutCreateWindow("PfnnDemo");

	/* Init GLEW */

	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		fprintf_s(stderr, "Error: %s\n", glewGetErrorString(err));
		exit(1);
	}

	glutDisplayFunc( draw );
	glutMouseFunc(mouseFunc);
	glutMotionFunc(mouseMove);
	glutMainLoop();
}

int testSDL()
{
	//The window we'll be rendering to  
	SDL_Window* window = NULL;

	//The surface contained by the window  
	SDL_Surface* screenSurface = NULL;

	//Initialize SDL  ��ʼ��SDL��Ƶ��ϵͳ  
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
		return 0;
	}

	//Create window  ��������  
	window = SDL_CreateWindow("Hello SDL",//���ڱ���  
		SDL_WINDOWPOS_UNDEFINED,//����λ������  
		SDL_WINDOWPOS_UNDEFINED,
		640, //���ڵĿ���  
		480,//���ڵĸ߶�  
		SDL_WINDOW_SHOWN  //��ʾ����  
		);
	if (window == NULL)
	{
		printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
		return 0;
	}

	//Get window surface  
	screenSurface = SDL_GetWindowSurface(window);

	//Fill the surface green   �����ɫΪ��ɫ  
	SDL_FillRect(screenSurface, NULL, SDL_MapRGB(screenSurface->format, 0x00, 0xff, 0x00));

	//Update the surface  
	SDL_UpdateWindowSurface(window);

	//Wait two seconds ��ʱ2000����  
	SDL_Delay(2000);


	//Destroy window  
	SDL_DestroyWindow(window);

	//Quit SDL subsystems  
	SDL_Quit();

	return 1;
}


int main(int argc, char* argv[])
{
//	bool testRes1 = testShaderClass(argc, argv);
//	bool testRes2 = testAreaClass();
//	bool testRes3 = testCameraOrbitClass();
//	bool testRes4 = testCharacterClass(argc, argv);
//	bool testRes5 = testHeightmapClass(argc, argv);
//	bool testRes6 = testPfnnClass();
//	bool testRes7 = testTrajectoryClass();
//	bool testRes8 = testInitFunc();
//	testOpenglTimer(argc, argv);
//	testSDL();


	return 0;
}

#endif // _TEST_