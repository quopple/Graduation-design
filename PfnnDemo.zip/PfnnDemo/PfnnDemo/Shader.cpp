#include "Shader.h"

#include <fstream>
#include <sstream>
#include <string>

Shader::Shader()
	: program(0)
	, vs(0)
	, fs(0) { }

Shader::~Shader() 
{
	if (vs != 0) { glDeleteShader(vs); vs = 0; }
	if (fs != 0) { glDeleteShader(fs); fs = 0; }
	if (program != 0) { glDeleteShader(program); program = 0; }
}

void Shader::load_shader(const char* filename, GLenum type, GLuint *shader) 
{
	std::ifstream file(filename);
	
	if ( !file ) 
	{
		fprintf(stderr, "Cannot load file %s\n", filename);
		file.close();
		exit(1);
	}
	std::ostringstream ss;
	ss << file.rdbuf();
	auto s = ss.str();
	const char* contents = s.data();

	ss.str("");
	file.close();
	
	*shader = glCreateShader(type);

	glShaderSource(*shader, 1, (const char**)&contents, NULL);
	glCompileShader(*shader);

	char log[2048];
	int i;
	glGetShaderInfoLog(*shader, 2048, &i, log);
	log[i] = '\0';
	if (strcmp(log, "") != 0) { printf("%s\n", log); }

	int compile_error = 0;
	glGetShaderiv(*shader, GL_COMPILE_STATUS, &compile_error);
	if (compile_error == GL_FALSE) 
	{
		fprintf_s(stderr, "Compiler Error on Shader %s.\n", filename);
		exit(1);
	}
}


void Shader::load(const char* vertex, const char* fragment) 
{
	if (vs != 0) { glDeleteShader(vs); vs = 0; }
	if (fs != 0) { glDeleteShader(fs); fs = 0; }
	if (program != 0) { glDeleteShader(program); program = 0; }

	program = glCreateProgram();
	load_shader(vertex, GL_VERTEX_SHADER, &vs);
	load_shader(fragment, GL_FRAGMENT_SHADER, &fs);
	glAttachShader(program, vs);
	glAttachShader(program, fs);
	glLinkProgram(program);

	char log[2048];
	int i;
	glGetProgramInfoLog(program, 2048, &i, log);
	log[i] = '\0';
	if (strcmp(log, "") != 0) { printf("%s\n", log); }
}
