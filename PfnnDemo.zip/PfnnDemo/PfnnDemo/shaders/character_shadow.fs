#version 120
  
void main() {
  gl_FragColor = vec4(0);
} 