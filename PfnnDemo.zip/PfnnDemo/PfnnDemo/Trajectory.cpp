#include "Trajectory.h"


Trajectory::Trajectory(const int length, const int subsampleRate, float w, const int nucp)
	: LENGTH(length)
	, subsampleRate(subsampleRate)
	, width(w)
	, target_dir(glm::vec3(0, 0, 1))
	, target_vel(glm::vec3(0))
	, positions(length)
	, directions(length)
	, rotations(length)
	, heights(length)
	, ucps(nucp, std::vector<float>(length))
	{}

Trajectory::~Trajectory()
{
}
